package com.masoud.raja;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(7,16,24);
    private static final int PANEL = Color.rgb(11,21,30);
    private static final int FIELD = Color.rgb(10,20,28);
    private static final int TEXT = Color.rgb(244,247,251);
    private static final int MUTED = Color.rgb(154,171,186);
    private static final int BLUE = Color.rgb(13,125,245);
    private static final int GREEN = Color.rgb(0,200,83);
    private static final int RED = Color.rgb(255,39,55);

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WebView webView;
    private EditText phone, password, origin, destination, travelDate, trainNumber, minPrice, maxPrice, adults, children, refresh, passengerName, passengerFamily, passengerNational, passengerBirth;
    private CheckBox priceMode, coupe, alarm;
    private TextView status, logView, passengerCountLabel;
    private LinearLayout runPanel, passengerPanel, browserPanel, passengerList;
    private Button startBtn, stopBtn;
    private final List<Passenger> passengers = new ArrayList<>();
    private boolean running = false;
    private boolean loggedIn = false;
    private boolean searchSubmitted = false;
    private boolean reserved = false;
    private long nextRefreshAt = 0L;
    private Runnable monitorRunnable;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(BG);
        buildUi();
        setupWebView();
        loadAccount();
        showPanel(runPanel);
    }

    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView label(String text) {
        TextView v = new TextView(this); v.setText(text); v.setTextColor(TEXT); v.setTextSize(14); v.setGravity(Gravity.RIGHT); v.setPadding(0,dp(5),0,dp(4)); return v;
    }
    private EditText field(String hint) {
        EditText e = new EditText(this); e.setHint(hint); e.setHintTextColor(MUTED); e.setTextColor(TEXT); e.setTextSize(16); e.setSingleLine(true); e.setGravity(Gravity.RIGHT); e.setBackgroundColor(FIELD); e.setPadding(dp(12),dp(10),dp(12),dp(10)); e.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(48))); return e;
    }
    private Button button(String text, int color) {
        Button b = new Button(this); b.setText(text); b.setTextColor(Color.WHITE); b.setTextSize(15); b.setBackgroundColor(color); b.setMinHeight(dp(48)); return b;
    }
    private LinearLayout section(String title) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(12),dp(10),dp(12),dp(12)); box.setBackgroundColor(PANEL);
        TextView t = label(title); t.setTextSize(17); t.setTypeface(null,1); box.addView(t,new LinearLayout.LayoutParams(-1,-2)); return box;
    }
    private void gap(LinearLayout p, int h){ Space s=new Space(this); p.addView(s,new LinearLayout.LayoutParams(1,dp(h))); }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        TextView title = new TextView(this); title.setText("MASOUD — ربات رجا"); title.setTextColor(TEXT); title.setTextSize(20); title.setTypeface(null,1); title.setGravity(Gravity.CENTER); title.setPadding(dp(12),dp(10),dp(12),dp(8)); root.addView(title,new LinearLayout.LayoutParams(-1,-2));

        LinearLayout tabs = new LinearLayout(this); tabs.setOrientation(LinearLayout.HORIZONTAL); tabs.setPadding(dp(8),0,dp(8),dp(8));
        Button tabRun=button("اجرا",BLUE), tabPassengers=button("مسافران",PANEL), tabBrowser=button("رجا",PANEL);
        tabs.addView(tabRun,new LinearLayout.LayoutParams(0,dp(46),1)); tabs.addView(tabPassengers,new LinearLayout.LayoutParams(0,dp(46),1)); tabs.addView(tabBrowser,new LinearLayout.LayoutParams(0,dp(46),1)); root.addView(tabs);

        FrameLayout body = new FrameLayout(this); root.addView(body,new LinearLayout.LayoutParams(-1,0,1));
        runPanel = makeRunPanel(); passengerPanel = makePassengerPanel(); browserPanel = makeBrowserPanel();
        body.addView(runPanel); body.addView(passengerPanel); body.addView(browserPanel);
        tabRun.setOnClickListener(v->showPanel(runPanel)); tabPassengers.setOnClickListener(v->showPanel(passengerPanel)); tabBrowser.setOnClickListener(v->showPanel(browserPanel));
        setContentView(root);
    }

    private void showPanel(View target){ runPanel.setVisibility(target==runPanel?View.VISIBLE:View.GONE); passengerPanel.setVisibility(target==passengerPanel?View.VISIBLE:View.GONE); browserPanel.setVisibility(target==browserPanel?View.VISIBLE:View.GONE); }

    private LinearLayout makeRunPanel(){
        ScrollView scroll=new ScrollView(this); LinearLayout p=new LinearLayout(this); p.setOrientation(LinearLayout.VERTICAL); p.setPadding(dp(10),0,dp(10),dp(20)); scroll.addView(p);
        LinearLayout account=section("حساب رجا"); phone=field("شماره موبایل حساب رجا"); phone.setInputType(InputType.TYPE_CLASS_PHONE); password=field("رمز عبور"); password.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD); account.addView(phone); gap(account,8); account.addView(password); p.addView(account); gap(p,8);
        LinearLayout trip=section("تنظیمات اجرای ربات"); origin=field("مبدا"); destination=field("مقصد"); travelDate=field("تاریخ شمسی مثل 1405/06/29"); trainNumber=field("شماره قطار"); trainNumber.setInputType(InputType.TYPE_CLASS_NUMBER); adults=field("بزرگسال"); adults.setInputType(InputType.TYPE_CLASS_NUMBER); adults.setText("1"); children=field("کودک"); children.setInputType(InputType.TYPE_CLASS_NUMBER); children.setText("0");
        trip.addView(origin); gap(trip,6); trip.addView(destination); gap(trip,6); trip.addView(travelDate); gap(trip,6); trip.addView(trainNumber); gap(trip,6);
        priceMode=new CheckBox(this); priceMode.setText("جستجو با بازه قیمت"); priceMode.setTextColor(TEXT); trip.addView(priceMode); minPrice=field("از قیمت (ریال)"); minPrice.setInputType(InputType.TYPE_CLASS_NUMBER); maxPrice=field("تا قیمت (ریال)"); maxPrice.setInputType(InputType.TYPE_CLASS_NUMBER); trip.addView(minPrice); gap(trip,6); trip.addView(maxPrice); gap(trip,6); trip.addView(adults); gap(trip,6); trip.addView(children);
        coupe=new CheckBox(this); coupe.setText("فقط کوپه دربست"); coupe.setTextColor(TEXT); alarm=new CheckBox(this); alarm.setText("آلارم پیدا شدن بلیت"); alarm.setTextColor(TEXT); alarm.setChecked(true); trip.addView(coupe); trip.addView(alarm); p.addView(trip); gap(p,8);
        LinearLayout live=section("کنترل زنده"); refresh=field("زمان رفرش (ثانیه)"); refresh.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL); refresh.setText("2"); live.addView(refresh); passengerCountLabel=label("مسافر ذخیره‌شده: 0"); live.addView(passengerCountLabel); p.addView(live); gap(p,8);
        LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL); startBtn=button("▶ اجرای ربات",GREEN); stopBtn=button("■ توقف",RED); stopBtn.setEnabled(false); actions.addView(startBtn,new LinearLayout.LayoutParams(0,dp(52),2)); actions.addView(stopBtn,new LinearLayout.LayoutParams(0,dp(52),1)); p.addView(actions); gap(p,8);
        status=label("● آماده"); status.setTextColor(GREEN); p.addView(status);
        LinearLayout logs=section("لاگ زنده رجا / ربات"); logView=new TextView(this); logView.setTextColor(TEXT); logView.setTextSize(12); logView.setGravity(Gravity.RIGHT); logView.setTextIsSelectable(true); logView.setMinHeight(dp(160)); logs.addView(logView); p.addView(logs);
        startBtn.setOnClickListener(v->startBot()); stopBtn.setOnClickListener(v->stopBot("توقف توسط کاربر"));
        priceMode.setOnCheckedChangeListener((b,checked)->{ trainNumber.setEnabled(!checked); minPrice.setEnabled(checked); maxPrice.setEnabled(checked); }); minPrice.setEnabled(false); maxPrice.setEnabled(false);
        LinearLayout container=new LinearLayout(this); container.setOrientation(LinearLayout.VERTICAL); container.addView(scroll,new LinearLayout.LayoutParams(-1,-1)); return container;
    }

    private LinearLayout makePassengerPanel(){
        ScrollView scroll=new ScrollView(this); LinearLayout p=new LinearLayout(this); p.setOrientation(LinearLayout.VERTICAL); p.setPadding(dp(10),0,dp(10),dp(20)); scroll.addView(p);
        LinearLayout form=section("افزودن مسافر"); passengerName=field("نام"); passengerFamily=field("نام خانوادگی"); passengerNational=field("کد ملی"); passengerNational.setInputType(InputType.TYPE_CLASS_NUMBER); passengerBirth=field("تاریخ تولد مثل 1370/01/01"); form.addView(passengerName); gap(form,6); form.addView(passengerFamily); gap(form,6); form.addView(passengerNational); gap(form,6); form.addView(passengerBirth); gap(form,8); Button add=button("+ افزودن مسافر",BLUE); form.addView(add); p.addView(form); gap(p,8); passengerList=section("مسافران ثبت‌شده"); p.addView(passengerList); add.setOnClickListener(v->addPassenger());
        LinearLayout container=new LinearLayout(this); container.setOrientation(LinearLayout.VERTICAL); container.addView(scroll,new LinearLayout.LayoutParams(-1,-1)); return container;
    }

    private LinearLayout makeBrowserPanel(){
        LinearLayout p=new LinearLayout(this); p.setOrientation(LinearLayout.VERTICAL); p.setPadding(dp(8),0,dp(8),dp(8)); webView=new WebView(this); p.addView(webView,new LinearLayout.LayoutParams(-1,0,1)); return p;
    }

    private void setupWebView(){
        WebSettings s=webView.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setLoadsImagesAutomatically(true); s.setJavaScriptCanOpenWindowsAutomatically(true); s.setUserAgentString(s.getUserAgentString()+" MASOUD-Android/1.0");
        webView.addJavascriptInterface(new JsBridge(),"MasoudBridge"); webView.setWebChromeClient(new WebChromeClient()); webView.setWebViewClient(new WebViewClient(){ @Override public void onPageFinished(WebView v,String url){ log("صفحه باز شد: "+url); if(running) handler.postDelayed(()->advanceAutomation(),500); } });
        webView.loadUrl("https://www.raja.ir/");
    }

    private void addPassenger(){
        String n=passengerName.getText().toString().trim(), f=passengerFamily.getText().toString().trim(), id=passengerNational.getText().toString().trim(), b=passengerBirth.getText().toString().trim();
        if(n.isEmpty()||f.isEmpty()||id.isEmpty()||b.isEmpty()){ toast("همه مشخصات مسافر را وارد کن."); return; }
        Passenger ps=new Passenger(n,f,id,b); passengers.add(ps); passengerName.setText(""); passengerFamily.setText(""); passengerNational.setText(""); passengerBirth.setText(""); renderPassengers();
    }
    private void renderPassengers(){
        while(passengerList.getChildCount()>1) passengerList.removeViewAt(1); for(int i=0;i<passengers.size();i++){ final int idx=i; Passenger ps=passengers.get(i); LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); Button del=button("حذف",RED); TextView t=label(ps.name+" "+ps.family+" | "+ps.national+" | "+ps.birth); row.addView(del,new LinearLayout.LayoutParams(dp(80),dp(44))); row.addView(t,new LinearLayout.LayoutParams(0,dp(44),1)); del.setOnClickListener(v->{ passengers.remove(idx); renderPassengers(); }); passengerList.addView(row); } passengerCountLabel.setText("مسافر ذخیره‌شده: "+passengers.size());
    }

    private void startBot(){
        if(origin.getText().toString().trim().isEmpty()||destination.getText().toString().trim().isEmpty()||travelDate.getText().toString().trim().isEmpty()){ toast("مبدا، مقصد و تاریخ را کامل کن."); return; }
        if(phone.getText().toString().trim().isEmpty()||password.getText().toString().trim().isEmpty()){ toast("حساب رجا را وارد کن."); return; }
        if(!priceMode.isChecked() && trainNumber.getText().toString().trim().isEmpty()){ toast("شماره قطار را وارد کن یا حالت بازه قیمت را فعال کن."); return; }
        saveAccount(); running=true; loggedIn=false; searchSubmitted=false; reserved=false; startBtn.setEnabled(false); stopBtn.setEnabled(true); status.setText("● در حال شروع..."); logView.setText(""); log("شروع اجرا | "+origin.getText()+" ← "+destination.getText()+" | "+travelDate.getText());
        if(!webView.getUrl().startsWith("https://www.raja.ir")) webView.loadUrl("https://www.raja.ir/"); else webView.loadUrl("https://www.raja.ir/");
        startMonitorLoop();
    }
    private void stopBot(String why){ running=false; if(monitorRunnable!=null) handler.removeCallbacks(monitorRunnable); startBtn.setEnabled(true); stopBtn.setEnabled(false); status.setText("● "+why); log(why); }

    private void startMonitorLoop(){
        monitorRunnable=new Runnable(){ @Override public void run(){ if(!running) return; if(searchSubmitted&&!reserved){ long now=System.currentTimeMillis(); if(now>=nextRefreshAt){ log("رفرش طبق زمان زنده: "+getRefreshSeconds()+" ثانیه"); webView.reload(); nextRefreshAt=now+(long)(getRefreshSeconds()*1000); } } handler.postDelayed(this,150); } }; handler.post(monitorRunnable);
    }
    private double getRefreshSeconds(){ try{return Math.max(0.5,Math.min(60,Double.parseDouble(refresh.getText().toString().trim())));}catch(Exception e){return 2.0;} }

    private void advanceAutomation(){
        if(!running) return; String url=webView.getUrl()==null?"":webView.getUrl();
        if(url.contains("registerticket")){ reserved=true; status.setText("● وارد صفحه مشخصات مسافر شد."); log("رزرو و ادامه خرید انجام شد؛ صفحه مشخصات مسافر باز شد."); fillPassengerPage(); if(alarm.isChecked()) toast("بلیت پیدا شد و رزرو انجام شد"); return; }
        if(!loggedIn){ injectLogin(); return; }
        if(!searchSubmitted){ injectSearchForm(); return; }
        inspectResultsAndReserve();
    }

    private void injectLogin(){
        String js="(function(){try{const txt=s=>(s||'').trim();const els=[...document.querySelectorAll('button,a,span,div')];let op=els.find(e=>txt(e.innerText)==='ورود / عضویت')||els.find(e=>txt(e.innerText).includes('ورود / عضویت'));if(op){op.click();setTimeout(()=>{let ins=[...document.querySelectorAll('input')].filter(x=>x.offsetParent!==null);if(ins.length>=2){ins[0].focus();ins[0].value="+q(phone.getText().toString())+";ins[0].dispatchEvent(new Event('input',{bubbles:true}));ins[1].focus();ins[1].value="+q(password.getText().toString())+";ins[1].dispatchEvent(new Event('input',{bubbles:true}));let bs=[...document.querySelectorAll('button')].filter(x=>x.offsetParent!==null);let b=bs.find(x=>txt(x.innerText)==='ورود')||bs.find(x=>txt(x.innerText).includes('ورود'));if(b){b.click();MasoudBridge.loginClicked();}else MasoudBridge.log('دکمه ورود پیدا نشد');}else MasoudBridge.log('فیلدهای ورود پیدا نشد');},700);return 'opening';}MasoudBridge.log('ورود/عضویت پیدا نشد');return 'missing';}catch(e){MasoudBridge.log('خطای ورود: '+e);return 'error';}})();";
        webView.evaluateJavascript(js,null);
    }

    private void injectSearchForm(){
        int total=parseInt(adults.getText().toString(),1)+parseInt(children.getText().toString(),0);
        String js="(async function(){const sleep=ms=>new Promise(r=>setTimeout(r,ms));const fire=(el)=>{el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));};try{let change=[...document.querySelectorAll('button,div,a')].find(x=>(x.innerText||'').trim()==='تغییر جستجو');if(change){change.click();await sleep(500);}async function station(kind,city){let comps=[...document.querySelectorAll('app-stations')];let c=comps.find(x=>((x.getAttribute('name')||'').toLowerCase()).includes(kind==='from'?'from':'to'));if(!c)return false;let clear=c.querySelector('.ng-clear-wrapper');if(clear)clear.click();let inp=c.querySelector('input[role=combobox]');if(!inp)return false;inp.focus();inp.value=city;fire(inp);await sleep(650);let opts=[...document.querySelectorAll('ng-dropdown-panel .ng-option')];let o=opts.find(x=>(x.innerText||'').trim()===city)||opts.find(x=>(x.innerText||'').includes(city));if(o){o.click();await sleep(250);return true;}return false;}let a=await station('from',"+q(origin.getText().toString().trim())+");let b=await station('to',"+q(destination.getText().toString().trim())+");if(!a||!b){MasoudBridge.log('مبدا یا مقصد تنظیم نشد');return;}let dateText="+q(travelDate.getText().toString().trim())+";let parts=dateText.replace(/-/g,'/').split('/').map(Number);let picker=document.querySelector('app-datepicker-single[name=oneWayDatePicker]');if(!picker||parts.length!==3){MasoudBridge.log('تقویم رجا پیدا نشد');return;}let cal=picker.querySelector('button.icon-calendar')||picker.querySelector('input[name=dp]');if(cal)cal.click();await sleep(650);let jy=parts[0],jm=parts[1],jd=parts[2];let monthNames=['','فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];for(let sel of [...document.querySelectorAll('select')].filter(x=>x.offsetParent!==null)){let opts=[...sel.options];let yo=opts.find(o=>(o.textContent||'').includes(String(jy)));if(yo){sel.value=yo.value;fire(sel);await sleep(220);continue;}let mo=opts.find(o=>(o.textContent||'').includes(monthNames[jm])||(o.textContent||'').trim()===String(jm));if(mo){sel.value=mo.value;fire(sel);await sleep(220);}}let dayFa=String(jd).replace(/[0-9]/g,d=>'۰۱۲۳۴۵۶۷۸۹'[Number(d)]);let nodes=[...document.querySelectorAll('button,td,span,div')].filter(x=>x.offsetParent!==null);let day=nodes.find(x=>{let t=(x.innerText||'').trim();let c=(x.className||'').toString().toLowerCase();return (t===String(jd)||t===dayFa)&&!c.includes('disabled')&&!c.includes('muted')&&!c.includes('outside');});if(!day){MasoudBridge.log('روز تاریخ در تقویم پیدا نشد');return;}day.click();await sleep(650);let dateInp=picker.querySelector('input[name=dp]');if(!dateInp||!(dateInp.value||'').trim()){MasoudBridge.log('تاریخ در رجا ثبت نشد');return;}let pb=document.querySelector('#dropdownPassenger');if(pb){pb.click();await sleep(250);let target="+total+";let options=[...document.querySelectorAll('.dropdown-menu *')].filter(x=>x.offsetParent!==null);let exact=options.find(x=>{let t=(x.innerText||'').replace(/\\D/g,'');return t===String(target)});if(exact)exact.click();}await sleep(250);"+(coupe.isChecked()?"let cc=[...document.querySelectorAll('input[type=checkbox]')].find(x=>((x.parentElement?.innerText)||'').includes('کوپه دربست'));if(cc&&!cc.checked)cc.click();":"")+"let bs=[...document.querySelectorAll('button')].filter(x=>x.offsetParent!==null);let s=bs.find(x=>(x.innerText||'').trim().includes('جستجو'));if(s){s.click();MasoudBridge.searchClicked();}else MasoudBridge.log('دکمه جستجو پیدا نشد');}catch(e){MasoudBridge.log('خطای تنظیم جستجو: '+e);}})();";
        webView.evaluateJavascript(js,null);
    }

    private void inspectResultsAndReserve(){
        String min=digitsOnly(minPrice.getText().toString()), max=digitsOnly(maxPrice.getText().toString()), wanted=digitsOnly(trainNumber.getText().toString());
        String js="(function(){try{const ds=s=>String(s||'').replace(/[^0-9۰-۹٠-٩]/g,'').replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d));let buttons=[...document.querySelectorAll('button')].filter(b=>b.offsetParent!==null&&(b.innerText||'').includes('رزرو بلیت'));MasoudBridge.log('پاسخ رجا: '+buttons.length+' دکمه رزرو دیده شد');for(let b of buttons){let card=b.closest('div.train-result')||b.closest('.train-result');if(!card)continue;let priceEl=card.querySelector('span.price');let price=priceEl?Number(ds(priceEl.textContent)):0;let timeline=card.querySelector('app-timeline');let tn='';if(timeline){tn=ds(timeline.getAttribute('data-trainnumber-to')||timeline.getAttribute('data-trainnumber-from')||'');}if(!tn){let m=(card.innerText||'').match(/شماره\\s*قطار\\s*[:：]?\\s*([0-9۰-۹٠-٩]+)/);if(m)tn=ds(m[1]);}MasoudBridge.log('کارت: قطار='+tn+' | قیمت='+price);let match="+(priceMode.isChecked()?"(("+(min.isEmpty()?"true":"price>=Number('"+min+"')")+")&&("+(max.isEmpty()?"true":"price<=Number('"+max+"')")+"))":"tn==='"+wanted+"'")+";if(match){b.click();MasoudBridge.reserveClicked();setTimeout(()=>{let c=[...document.querySelectorAll('button')].find(x=>(x.innerText||'').trim()==='ادامه خرید');if(c){c.click();MasoudBridge.continueClicked();}else MasoudBridge.log('رزرو زده شد ولی ادامه خرید پیدا نشد');},900);return 'reserved';}}MasoudBridge.notFound();return 'none';}catch(e){MasoudBridge.log('خطای بررسی نتیجه: '+e);return 'error';}})();";
        webView.evaluateJavascript(js,null);
    }

    private void fillPassengerPage(){
        if(passengers.isEmpty()) return; JSONArray arr=new JSONArray(); try{for(Passenger p:passengers){JSONObject o=new JSONObject();o.put("name",p.name);o.put("family",p.family);o.put("national",p.national);o.put("birth",p.birth);arr.put(o);}}catch(Exception ignored){}
        String js="(function(){try{const data="+arr.toString()+";const blocks=[...document.querySelectorAll('.passenger-registor')];const fire=e=>{e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));};data.slice(0,blocks.length).forEach((p,i)=>{let b=blocks[i];let n=b.querySelector('input[name=pName]');let f=b.querySelector('input[name=pFamily]');let birth=[...b.querySelectorAll('input')].find(x=>x.maxLength===10&&(x.placeholder||'').includes('/'));let nat=[...b.querySelectorAll('input')].find(x=>x.maxLength===10&&x!==birth&&!x.name);[[n,p.name],[f,p.family],[birth,p.birth],[nat,p.national]].forEach(z=>{if(z[0]){z[0].value=z[1];fire(z[0]);}});});MasoudBridge.log('مشخصات '+Math.min(data.length,blocks.length)+' مسافر وارد شد.');}catch(e){MasoudBridge.log('خطای تکمیل مسافر: '+e);}})();"; webView.evaluateJavascript(js,null);
    }

    private int parseInt(String s,int def){ try{return Math.max(0,Integer.parseInt(s.trim()));}catch(Exception e){return def;} }
    private String digitsOnly(String s){ return s==null?"":s.replaceAll("[^0-9]",""); }
    private String q(String s){ return JSONObject.quote(s==null?"":s); }
    private void log(String m){ runOnUiThread(()->{ String old=logView.getText().toString(); if(old.length()>20000) old=old.substring(old.length()-15000); logView.setText(old+"["+new java.text.SimpleDateFormat("HH:mm:ss",Locale.US).format(new java.util.Date())+"] "+m+"\n"); }); }
    private void toast(String m){ Toast.makeText(this,m,Toast.LENGTH_SHORT).show(); }
    private void saveAccount(){ getPreferences(MODE_PRIVATE).edit().putString("phone",phone.getText().toString()).putString("password",password.getText().toString()).apply(); }
    private void loadAccount(){ phone.setText(getPreferences(MODE_PRIVATE).getString("phone","")); password.setText(getPreferences(MODE_PRIVATE).getString("password","")); }

    private class JsBridge {
        @JavascriptInterface public void log(String m){ MainActivity.this.log(m); }
        @JavascriptInterface public void loginClicked(){ runOnUiThread(()->{ loggedIn=true; log("دکمه ورود زده شد؛ منتظر تکمیل ورود..."); handler.postDelayed(()->advanceAutomation(),2600); }); }
        @JavascriptInterface public void searchClicked(){ runOnUiThread(()->{ searchSubmitted=true; nextRefreshAt=System.currentTimeMillis()+(long)(getRefreshSeconds()*1000); log("جستجو ارسال شد؛ پایش مداوم فعال است."); handler.postDelayed(()->advanceAutomation(),1300); }); }
        @JavascriptInterface public void reserveClicked(){ runOnUiThread(()->{ reserved=true; status.setText("● بلیت پیدا شد؛ رزرو زده شد..."); log("رزرو بلیت کلیک شد."); }); }
        @JavascriptInterface public void continueClicked(){ runOnUiThread(()->log("ادامه خرید کلیک شد.")); }
        @JavascriptInterface public void notFound(){ runOnUiThread(()->{ reserved=false; status.setText("● یافت نشد؛ جستجوی مجدد..."); log("بلیط مطابق معیار فعلاً یافت نشد."); }); }
    }

    private static class Passenger { final String name,family,national,birth; Passenger(String n,String f,String id,String b){name=n;family=f;national=id;birth=b;} }
}
